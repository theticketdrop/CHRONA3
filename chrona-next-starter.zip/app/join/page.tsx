import { Button } from "@/components/ui/button";
export default function Join(){
  return <div className="max-w-lg mx-auto card animate-fadeIn">
    <h1 className="text-white text-2xl mb-4">Inscription bêta</h1>
    <div className="space-y-6">
      <section>
        <h3 className="text-white mb-2">1. Email</h3>
        <input placeholder="Email" className="w-full bg-white/5 rounded-xl p-3 border border-white/10"/>
      </section>
      <section>
        <h3 className="text-white mb-2">2. KYC Light</h3>
        <div className="grid grid-cols-2 gap-3">
          <input placeholder="Nom" className="bg-white/5 rounded-xl p-3 border border-white/10"/>
          <input placeholder="Prénom" className="bg-white/5 rounded-xl p-3 border border-white/10"/>
        </div>
        <input placeholder="Date de naissance" className="w-full bg-white/5 rounded-xl p-3 border border-white/10 mt-3"/>
      </section>
      <section>
        <h3 className="text-white mb-2">3. Pitch</h3>
        <textarea placeholder="Pourquoi rejoindre CHRONA ?" className="w-full h-24 bg-white/5 rounded-xl p-3 border border-white/10"/>
      </section>
      <Button className="w-full">Rejoindre</Button>
    </div>
  </div>
}