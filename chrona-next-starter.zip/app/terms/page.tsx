import { Card } from "@/components/ui/card";
export default function Terms(){
  return <div className="max-w-3xl mx-auto card animate-fadeIn">
    <h1 className="text-white text-2xl mb-4">Conditions générales d'utilisation</h1>
    <p className="text-white/70">Contenu légal à compléter…</p>
  </div>
}