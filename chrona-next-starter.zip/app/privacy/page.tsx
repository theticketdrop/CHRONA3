import { Card } from "@/components/ui/card";
export default function Privacy(){
  return <div className="max-w-3xl mx-auto card animate-fadeIn">
    <h1 className="text-white text-2xl mb-4">Politique de confidentialité</h1>
    <p className="text-white/70">Contenu RGPD à compléter…</p>
  </div>
}